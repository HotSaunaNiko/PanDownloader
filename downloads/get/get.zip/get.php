<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="max-age=604800, must-revalidate">
	<meta name="rating" content="general">
	<!--<link href="/rss/index.php" rel="alternate" type="application/rss+xml" title="News" />-->
	<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
	<title>Library Genesis</title>
		
	<!--[if IE 6]>
	<style>
		body {behavior: url("/csshover3.htc");}
		#menu li .drop {background:url("img/drop.gif") no-repeat right 8px; 
	</style>
	<![endif]-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">	
	
<link href="/css/font.min.css" rel="stylesheet">	
<style>
nav.navbar .dropdown:hover > .dropdown-menu {
 display: block; 
}
.bd-placeholder-img {
	font-size: 1.125rem;
	text-anchor: middle;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
}
@media (min-width: 768px) {
			.bd-placeholder-img-lg {
			font-size: 3.5rem;
		}
	}

.panel-heading .accordion-toggle:after {
    font-family: "Glyphicons Halflings";  
    content: "\e114";    
    float: right;       
    color: grey;         
}
.panel-heading .accordion-toggle.collapsed:after {
    content: "\e080";   
}
.tooltip-inner {
    max-width: 350px;
    width: 350px; 
}
h1 {
	display: block; 
	font-size: 1.8rem; 
	font-weight: bold; 
	font-family: Georgia, "Times New Roman", Times, serif;  color: #A00000; 
}
#tablelibgen td { 
	font-family: "Pt Sans", Tahoma, Helvetica, sans-serif; 
	margin: 0; 
	padding: 0em 3px; 
	font-size: 1rem;
}

#tablelibgen1 td { 
	font-family: "Pt Sans", Tahoma, Helvetica, sans-serif; 
	margin: 0; 
	padding: 0em 3px; 
	font-size: 1rem;
}

.taghide {
    display: none; 
}
.taghide + label ~ div {
    display: none;
}
/* оформляем текст label */
.taghide + label {
    display: inline-block; 
}
/* вид текста label при активном переключателе */

/* когда чекбокс активен показываем блоки с содержанием  */
.taghide:checked + label + div {
    display: block; 
}



/*.navbar {
	background-color: #BBBBBB;
}*/
	</style>

	<link rel="stylesheet" href="/css/dark-mode.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<style>p {margin: 0;}</style>




</head>
<body><script>
(function () {
    var script = document.createElement('script');
var COOKIE_NAME = 'test_variant';
    var valueFromCookie = getCookie(COOKIE_NAME);
    var variant;

    function getCookie(name) {
    var cookiesList = document.cookie.split(';');

for (var i = 0, length = cookiesList.length; i < length; i += 1) {
    var cookie = cookiesList[i].split('=');

    if (cookie[0].trim() === name) {
    return Number(cookie[1].trim());
}
}

    return null;
}

    function setCookie(name, value) {
    document.cookie = [
    name + '=' + value,
    'SameSite=Lax',
    'path=/',
    'Expires=' +
    new Date(new Date().getTime() + 14 * 24 * 60 * 60 * 1000).toUTCString(),
    ].join(';');
}

    if (valueFromCookie === null) {
    variant = Math.random();
    setCookie(COOKIE_NAME, variant);
} else {
    variant = valueFromCookie;
}
    if (variant < 0.5) {
    script.setAttribute('data-domain', 'features-2562_0');
    script.setAttribute('src', '//inopportunefable.com/7d/78/3d/7d783dc7f86db4429028d485a085a9b7.js');

    window.addEventListener('DOMContentLoaded', function () {
    if (
    document.body.querySelector('script[data-domain="features-2562_0"]') ===
    null
    ) {
    document.body.appendChild(script);
}
});
} else {
    script.setAttribute('data-domain', 'features-2562_1');
    /* dynamic */ script.setAttribute('src', '//inopportunefable.com/imw/zIaHmB/0nCsRHnp/SCgHBcfS8hOrJa4/854J8Er1gxI1LoK32BBg/zk6iz1O4Lg/JiGAhxO4-ENw6/hJq3/4gzKxMG_mlKcbOl/08XbF_y6D5em/sH0oBrSV1A0hSBB/GxBx');

    window.addEventListener('DOMContentLoaded', function () {
    if (
    document.body.querySelector('script[data-domain="features-2562_1"]') ===
    null
    ) {
    document.body.appendChild(script);
}
});
}
})();
</script>    
<nav class="navbar navbar-expand-md navbar-dark bg-secondary  mb-1">
  
   <a class="navbar-brand" href="/index.php">
    <img src="/img/logo.png"  height="30" alt="">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/community/app.php/article/news">NEWS <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/community/">FORUM <span class="sr-only">(current)</span></a>
      </li>
	
      <li class="nav-item dropdown">
<a class="btn btn-secondary dropdown-toggle" href="/community/ucp.php?mode=login" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          LOGIN
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdown01">    
          <a class="dropdown-item" href="/community/ucp.php?mode=register">Register</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          DOWNLOAD
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdown01">      

          <a class="dropdown-item" href="/mirrors.php">Mirrors</a>
          <a class="dropdown-item" href="http://libgenfrialc7tguyjywa36vtrdcplwpxaw43h6o63dmmwhvavo5rqqd.onion/">TOR</a>

	<div class="dropdown-divider"></div>
         <h6 class="dropdown-header">P2P</h6>
          <a class="dropdown-item" href="/torrents/">Torrents</a>
          <a class="dropdown-item" href="https://ipdl.cat/data/torrents.html">Torrents status</a>
          <a class="dropdown-item" href="/nzb/">Usenet (*.nzb)</a>
          <a class="dropdown-item" href="/soft/">Soft</a>
	<!--https://phillm.net/libgen-stats-table.php-->




	<div class="dropdown-divider"></div>
         <h6 class="dropdown-header">DB Dumps</h6>
          <a class="dropdown-item" href="/dirlist.php?dir=dbdumps">Libgen</a>
          <a class="dropdown-item" href="http://libgen.rs/dbdumps/">libgen.rs (gen.lib.rus.ec)</a>

	<!--<div class="dropdown-divider"></div>
 	 <a class="dropdown-item" href="/magz0/">Unsorted magz</a>
 	 <a class="dropdown-item" href="/fict0/">Unsorted fiction</a>

	 <a class="dropdown-item" href="/comics4/">Unsorted comics</a>
        </div>-->

      </li>

      <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="librarian.php" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          UPLOAD
        </a>
        <div class="dropdown-menu" aria-labelledby="dropdown01">  
          <a class="dropdown-item" href="ftp://ftp.libgen.bz/upload/">FTP</a> 
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="/index.php?req=fmode:last&topics1=all" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          LAST
        </a>

        <div class="dropdown-menu" aria-labelledby="dropdown01">
	<a class="dropdown-item" href="/index.php?req=fmode:last&topics1=all"><b>Files</b></a>

          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=l">Libgen</a>
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=a">Scientific Articles</a> 
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=f">Fiction</a> 
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=c">Comics</a> 
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=m">Magazines</a> 
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=s">Standards</a> 
          <a class="dropdown-item" href="/index.php?req=fmode:last&topics%5B%5D=r">Fiction RUS</a>
	<div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/index.php?req=mode:last&curtab=e">Editions</a> 
          <a class="dropdown-item" href="/index.php?req=mode:last&curtab=s">Series</a>
          <a class="dropdown-item" href="/index.php?req=mode:last&curtab=p">Publishers</a> 
        <!--  <a class="dropdown-item" href="/index.php?req=mode:last&curtab=f">Files</a> -->
          <a class="dropdown-item" href="/index.php?req=mode:last&curtab=a">Authors</a> 
          <a class="dropdown-item" href="/index.php?req=mode:last&curtab=w">Works</a>


  
        </div>


      </li>

      <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          OTHERS
        </a>

        <div class="dropdown-menu" aria-labelledby="dropdown01">  
          <a class="dropdown-item" href="json.php">API</a> 
          <a class="dropdown-item" href="rss.php">RSS</a> 
          <a class="dropdown-item" href="top.php">Top 100 users</a> 
          <a class="dropdown-item" href="stat.php">Stats</a>

	<a class="dropdown-item" href="topics.php">Topics</a>

          <a class="dropdown-item" href="batchsearchindex.php">Batch search</a>  
          <a class="dropdown-item" href="biblioservice.php">Bibliographic services</a>
          <a class="dropdown-item" href="https://wiki.mhut.org/software:libgen_desktop">Libgen librarian for desktop</a>


          <a class="dropdown-item" href="/code/">Source (PHP)</a>
          <a class="dropdown-item" href="/soft/">LG soft</a>
          <!--<a class="dropdown-item" href="/import/">Import local files in LG format</a>-->
          <a class="dropdown-item" href="https://z-library.se/fulltext/">Full text search</a>



        </div>
      </li>



     <!-- <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="topics.php" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          Topics
        </a>
      </li>
-->

      <li class="nav-item dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          LINKS
        </a>

        <div class="dropdown-menu" aria-labelledby="dropdown01">  


          
          <a class="dropdown-item" href="http://sci-hub.ru">Sci-hub</a> 
          <a class="dropdown-item" href="http://magzdb.org">Magzdb.org</a>

          <a class="dropdown-item" href="http://nlr.ru/rlin/Periodika_rus.php">РНБ</a>
          <a class="dropdown-item" href="http://rsl.ru/">РГБ</a>
          <a class="dropdown-item" href="http://loc.gov/">LOC</a>
          <a class="dropdown-item" href="https://comicvine.gamespot.com/">ComicVine</a>
          <a class="dropdown-item" href="http://cyberleninka.ru/">Cyberleninka</a>
          <a class="dropdown-item" href="http://lib.rus.ec/">Lib.rus.ec</a>
          <a class="dropdown-item" href="http://flibusta.net/">Flibusta.net</a>
          <a class="dropdown-item" href="http://goodreads.com/">Goodreads.com</a>
          <a class="dropdown-item" href="http://worldcat.org/">Worldcat.org</a>
          <a class="dropdown-item" href="https://wiki.archiveteam.org/">Archive team</a>
          <a class="dropdown-item" href="https://www.reddit.com/r/libgen/">Reddit</a>
          <a class="dropdown-item" href="http://annas-archive.org/">Anna's Archive</a>
          <a class="dropdown-item" href="https://welib.org/">Welib</a>
          <a class="dropdown-item" href="https://open-slum.org/">The Shadow Library Uptime Monitor</a>

        </div>

      </li>


      <li class="nav-item dropdown">
        <a class="btn btn-secondary" href="index.php?req=mode:req&curtab=e" role="button" id="dropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
          WANTED
        </a>
      </li>

    </ul>
  </div>

  <div class="nav-link">

    <div class="custom-control custom-switch">
      <input type="checkbox" class="custom-control-input" id="darkSwitch">
      <label class="custom-control-label" for="darkSwitch">🌓</label>
    </div>
    <script src="/js/dark-mode-switch.js"></script>
  </div>
   <a class="navbar-brand" href="setlang.php?md5=757701841083d9106327a8580a883d2e&key=9JPT9TFS5ZH1L2CE&lang=ru">RU</a>
</nav>
<span></span><table id=main  align="center" border=1>



		
		<tr>
	
		<td align="left" valign="top" bgcolor="#F5F6CE" width=1 nowrap></td>
		<td align="center" valign="top" bgcolor="#A9F5BC"><a href="get.php?md5=757701841083d9106327a8580a883d2e&key=D96JP0H32SBH9REA"><h2>GET</h2></a></td>
		<td align="left" valign="top" bgcolor="#F5F6CE" width=1></td>
		</tr>
		<tr>
	
		<td bgcolor="#F5F6CE" valign=top></td>
		<td>
<table width=700 border=0>
<tr><td  colspan=3 bgcolor="#F5F6CE" align="center"><nobr><script type="text/javascript">
	atOptions = {
		'key' : '8653b0dc857008353ad71d83dad80b6d',
		'format' : 'iframe',
		'height' : 90,
		'width' : 728,
		'params' : {}
	};
	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://inopportunefable.com/8653b0dc857008353ad71d83dad80b6d/invoke.js"></scr' + 'ipt>');
</script></nobr></td></tr>
<tr><td  rowspan=2><a href="/covers/1714000/757701841083d9106327a8580a883d2e.jpg"><img src="/covers/1714000/757701841083d9106327a8580a883d2e.jpg" width=300></a></td><td>Title: Bevægeapparatets anatomi<br>
Series: <br>
Author(s): Finn Bojsen-Møller, Erik B. Simonsen, Jørgen Tranum-Jensen<br>
Publisher: Munksgaard<br>
Year: 2014<br>
ISBN: 9788762809000; 8762809008<br></td>

<tr><td><textarea rows='9' name='bibtext' id='bibtext' readonly cols='60'>@book{book:{92724958},
   title =     {Bevægeapparatets anatomi},
   author =    {Finn Bojsen-Møller, Erik B. Simonsen, Jørgen Tranum-Jensen},
   publisher = {Munksgaard},
   isbn =      {9788762809000; 8762809008},
   year =      {2014},
   edition =   {13},
   url =       {libgen.li/file.php?md5=757701841083d9106327a8580a883d2e}}</textarea></td></tr>
<tr><td colspan=3><p style='text-align:center'>
<a href='https://www.worldcat.org/search?qt=worldcat_org_bks&q=Bev%C3%A6geapparatets%20anatomi&fq=dt%3Abks'>Search in WorldCat</a> 
<a href='https://www.goodreads.com/search?utf8=✓&query=Bev%C3%A6geapparatets%20anatomi'>Search in Goodreads</a><br>
<a href='https://www.abebooks.com/servlet/SearchResults?tn=Bev%C3%A6geapparatets%20anatomi&pt=book&cm_sp=pan-_-srp-_-ptbook'>Search in AbeBooks</a></td></tr>
</table>
</td>
		<td bgcolor="#F5F6CE" valign=top></td>
		</tr>

		<tr><td></td><td colspan=2></td></tr>
		<tr><td colspan=3 bgcolor="#F5F6CE" align="center"><script type="text/javascript">
	atOptions = {
		'key' : '8653b0dc857008353ad71d83dad80b6d',
		'format' : 'iframe',
		'height' : 90,
		'width' : 728,
		'params' : {}
	};
	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://inopportunefable.com/8653b0dc857008353ad71d83dad80b6d/invoke.js"></scr' + 'ipt>');
</script><br><script type="text/javascript">
	atOptions = {
		'key' : '8653b0dc857008353ad71d83dad80b6d',
		'format' : 'iframe',
		'height' : 90,
		'width' : 728,
		'params' : {}
	};
	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://inopportunefable.com/8653b0dc857008353ad71d83dad80b6d/invoke.js"></scr' + 'ipt>');
</script></td></tr>
		</table><nav class="navbar sticky-bottom navbar-expand-sm navbar-dark bg-secondary">
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
	    <a class="nav-link" href="#" data-toggle="modal" data-target="#dmcamodal">DMCA</a>
      </li>
      <li class="nav-item">
	    <a class="nav-link" href="#" data-toggle="modal" data-target="#aboutmodal">ABOUT</a>
      </li>
      <li class="nav-item">
	    <a class="nav-link" href="#" data-toggle="modal" data-target="#donatemodal" >DONATE</a>
      </li>
	
    </ul>
	<span class="navbar-text">Users online 11688</span>
  </div>
</nav>

<!-- Modal Donate -->
<div class="modal fade text-dark" id="donatemodal" tabindex="-1" aria-labelledby="donatemodalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="donatemodalLabel">Donate</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <a href="bitcoin://bc1qlv9lwa5vncm2jjrxyhddfcvu0z3u5vn0s9672r">Bitcoin</a>
	<br>
        <a href="monero:48WhyKv4D9x53SyDFNYuMsHsDzuHXEcht4mWoFtXtE3k4KZ3A7goi3CQWBQQZ3A8PSK7CpwnAFKLnfGiZTAbEpcaCQCghvN">Monero</a>
      </div>
    </div>
  </div>
</div>

<!-- Modal About -->
<div class="modal fade text-dark" id="aboutmodal" tabindex="-1" aria-labelledby="aboutmodalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="aboutmodalLabel">About</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">


<div id="about">
The Library Genesis aggregator is a community aiming at collecting and cataloging items descriptions for the most part of scientific, 
scientific and technical directions, as well as file metadata. In addition to the descriptions, 
the aggregator contains only links to third-party resources hosted by users. 
All information posted on the website is collected from publicly available public Internet resources and is intended solely for informational purposes.  
</div>
      </div>
    </div>
  </div>
</div>

<!-- Modal DMCA -->
<div class="modal fade text-dark" id="dmcamodal" tabindex="-1" aria-labelledby="dmcamodalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="dmcamodalLabel">About</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<div id="dmca">
Library Genesis - aggregator items is a website that collects and organizes online items from users. 
Item aggregation is done for fact-finding purposes, and website Library Genesis respects the rights of copyright holders and respect dcma.

     Removing Content From Library Genesis / DMCA Policy
     Library Genesis respects the intellectual property of others.
</div>

    <div class="dmca">
     If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement and is accessible on this site, you may notify our copyright agent, as set forth in the Digital Millennium Copyright Act of 1998 (DMCA). For your complaint to be valid under the DMCA, you must provide the following information when providing notice of the claimed copyright infringement:
</div>
    <div class="dmca">
     * A physical or electronic signature of a person authorized to act on behalf of the copyright owner Identification of the copyrighted work claimed to have been infringed <br />
     * Identification of the material that is claimed to be infringing or to be the subject of the infringing activity and that is to be removed <br />
     * Information reasonably sufficient to permit the service provider to contact the complaining party, such as an address, telephone number, and, if available, an electronic mail address <br />
     * A statement that the complaining party "in good faith believes that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or law" <br />
     * A statement that the "information in the notification is accurate", and "under penalty of perjury, the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed" <br />
     The above information must be submitted as a written, faxed or emailed notification to the following Designated Agent: ianzlib@protonmail.com. Appeals will be reviewed within 72 hours.</div>


      </div>
    </div>
  </div>
</div>


	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.5/dist/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
	<script src="/js/form-validation.js"></script>
	<script>
$('[data-toggle="tooltip"]').tooltip();
$('.btn-tooltip-bottom').tooltip({
    placement: 'bottom'
});
</script>

</body>
</html>